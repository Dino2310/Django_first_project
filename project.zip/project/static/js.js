let a = document.querySelector('.image-div')

setInterval(
    () => { a.style.color = 'red' }, 500
)
setInterval(
    () => { a.style.color = 'black' }, 1000
)
