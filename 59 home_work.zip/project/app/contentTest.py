conatact = {
    'text':'Используйте нашу контактную форму для всех информационных запросов или свжитесь с нами на прямую, используя контактную информацию ниже.',
    'callMe':'Свяжись с нами по электронной почте или телефону по телефону',
    'textOffice':'Расположение нашего офиса',
    'textTel':'Телефон (стационарный)',
    'addr':'The interion Design Studio Company The Courtytad, Al, Quoz 1, Колорадо США',
    'tel':['+ 912 3 567 8987','+ 912 5 252 3336'],
    'title': "Контакты",
}

abouts = {'text':'Paragraph. Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro repudiandae in debitis error dolorum doloribus perferendis quod eaque inventore aperiam modi ipsam voluptatibus beatae, esse necessitatibus dignissimos distinctio minima et id molestias sed accusantium? Consequatur, a omnis doloremque nesciunt fugiat quo veritatis modi, rerum aliquid distinctio ipsum cupiditate laboriosam at!'
}
